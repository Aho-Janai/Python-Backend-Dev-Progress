import uuid

import click
from sqlalchemy.exc import IntegrityError

from app import app, db
from app.atn_import import AtnError, parse_atn, to_rows
from app.models import PsStroke


@app.cli.command('import-atn')
@click.argument('path', type=click.Path(exists=True, dir_okay=False))
@click.option('--session-id', default=None, help='Defaults to a new UUID.')
def import_atn(path, session_id):
    """Import the brush/eraser strokes of a Photoshop .atn recording."""
    session_id = session_id or str(uuid.uuid4())
    try:
        result = parse_atn(path)
    except AtnError as e:
        raise click.ClickException(f'cannot read {path}: {e}')
    rows = to_rows(result.strokes, session_id)
    db.session.add_all(PsStroke(**row) for row in rows)
    try:
        db.session.commit()
    except IntegrityError:
        db.session.rollback()
        raise click.ClickException(f'session {session_id} already has these strokes')
    for i, why in result.skipped:
        click.echo(f'skipped command {i}: {why}')
    for w in result.warnings:
        click.echo(f'warning: {w}')
    click.echo(f'imported {len(rows)} stroke(s) into session {session_id}')
